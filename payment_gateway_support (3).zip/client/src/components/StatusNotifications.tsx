import { useEffect, useState } from "react";
import { Bell, CheckCircle, XCircle, AlertCircle } from "lucide-react";

type Notification = {
  id: number;
  type: "success" | "error" | "info";
  title: string;
  message: string;
  timestamp: Date;
};

export function StatusNotifications() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);

  // Simular recebimento de notificações (em produção, virá de WebSocket ou API)
  useEffect(() => {
    // Exemplo de notificações
    const exampleNotifications: Notification[] = [
      {
        id: 1,
        type: "success",
        title: "Transação Aprovada",
        message: "Pagamento de R$ 150,00 foi aprovado com sucesso",
        timestamp: new Date(Date.now() - 300000), // 5 minutos atrás
      },
      {
        id: 2,
        type: "info",
        title: "Limite Alterado",
        message: "Seu limite de compras foi atualizado para R$ 5.000,00",
        timestamp: new Date(Date.now() - 3600000), // 1 hora atrás
      },
    ];

    setNotifications(exampleNotifications);
  }, []);

  const getIcon = (type: Notification["type"]) => {
    switch (type) {
      case "success":
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case "error":
        return <XCircle className="w-5 h-5 text-red-600" />;
      case "info":
        return <AlertCircle className="w-5 h-5 text-blue-600" />;
    }
  };

  const getBgColor = (type: Notification["type"]) => {
    switch (type) {
      case "success":
        return "bg-green-50 border-green-200";
      case "error":
        return "bg-red-50 border-red-200";
      case "info":
        return "bg-blue-50 border-blue-200";
    }
  };

  return (
    <div className="relative">
      {/* Botão de notificações */}
      <button
        onClick={() => setShowNotifications(!showNotifications)}
        className="relative p-2 hover:bg-gray-100 rounded-full transition-colors"
      >
        <Bell className="w-6 h-6 text-gray-700" />
        {notifications.length > 0 && (
          <span className="absolute top-0 right-0 w-5 h-5 bg-[#FF6600] text-white text-xs rounded-full flex items-center justify-center">
            {notifications.length}
          </span>
        )}
      </button>

      {/* Painel de notificações */}
      {showNotifications && (
        <div className="absolute right-0 top-12 w-80 bg-white rounded-lg shadow-lg border border-gray-200 z-50 max-h-96 overflow-y-auto">
          <div className="p-4 border-b border-gray-200">
            <h3 className="font-semibold text-gray-900">Notificações</h3>
          </div>

          {notifications.length === 0 ? (
            <div className="p-8 text-center text-gray-500">
              Nenhuma notificação
            </div>
          ) : (
            <div className="divide-y divide-gray-100">
              {notifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`p-4 hover:bg-gray-50 cursor-pointer border-l-4 ${getBgColor(
                    notification.type
                  )}`}
                >
                  <div className="flex items-start gap-3">
                    {getIcon(notification.type)}
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900 text-sm">
                        {notification.title}
                      </h4>
                      <p className="text-sm text-gray-600 mt-1">
                        {notification.message}
                      </p>
                      <p className="text-xs text-gray-400 mt-2">
                        {notification.timestamp.toLocaleString("pt-BR")}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
