import { useState } from "react";
import { ChevronRight, ChevronDown, Phone, MessageCircle, FileText, Users } from "lucide-react";
import { useLocation } from "wouter";

type FAQItem = {
  question: string;
  answer: string;
};

type Channel = {
  icon: typeof Phone;
  title: string;
  description: string;
  details: string;
};

export default function HelpCenter() {
  const [, setLocation] = useLocation();
  const [expandedFAQ, setExpandedFAQ] = useState<number | null>(null);
  const [expandedChannel, setExpandedChannel] = useState<number | null>(null);

  const faqs: FAQItem[] = [
    {
      question: "Como consulto a fatura do meu cartão de crédito?",
      answer: "Você pode consultar sua fatura através do app, internet banking ou solicitando pelo WhatsApp. A fatura fica disponível 5 dias antes do vencimento."
    },
    {
      question: "Onde altero o vencimento da fatura?",
      answer: "Acesse o app > Cartões > Configurações > Alterar vencimento. Você pode escolher entre os dias 5, 10, 15, 20 ou 25 de cada mês."
    }
  ];

  const channels: Channel[] = [
    {
      icon: MessageCircle,
      title: "Whatsapp Itaú",
      description: "Atendimento 24h por WhatsApp",
      details: "Adicione o número (11) 3003-3030 nos seus contatos e inicie uma conversa. Nosso atendimento é 24 horas, 7 dias por semana. Você pode consultar saldo, fatura, fazer transferências e muito mais!"
    },
    {
      icon: Users,
      title: "acessível em libras",
      description: "Atendimento em Língua Brasileira de Sinais",
      details: "Atendimento por videochamada com intérpretes de Libras de segunda a sexta, das 8h às 20h. Acesse pelo app ou ligue para 0800 722 1722 (ligação gratuita)."
    },
    {
      icon: Phone,
      title: "telefones",
      description: "Centrais de atendimento telefônico",
      details: "Capitais e regiões metropolitanas: 3003-3030 | Demais localidades: 0800 722 3030 | SAC: 0800 728 0728 | Ouvidoria: 0800 570 0011 | Deficientes auditivos: 0800 722 1722"
    },
    {
      icon: FileText,
      title: "ouvidoria",
      description: "Canal para reclamações e sugestões",
      details: "A Ouvidoria é um canal independente para quando você não ficou satisfeito com a solução apresentada pelos canais de atendimento. Telefone: 0800 570 0011 | Disponível 24 horas."
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm py-4 px-6 flex items-center">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-[#FF6600] to-[#FF8533] rounded-full flex items-center justify-center shadow-md">
            <span className="text-white font-bold text-xl">itaú</span>
          </div>
          <h1 className="text-xl font-semibold text-gray-900">Central de Ajuda</h1>
        </div>
      </header>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        {/* FAQ Section */}
        <div className="bg-white mt-6 mx-4 rounded-lg shadow-sm border border-gray-200">
          {faqs.map((faq, index) => (
            <div key={index}>
              <button
                onClick={() => setExpandedFAQ(expandedFAQ === index ? null : index)}
                className="w-full px-6 py-5 flex items-center justify-between hover:bg-blue-50 transition-all duration-200 border-b border-gray-100 last:border-b-0"
              >
                <span className="text-left text-gray-900 font-normal">{faq.question}</span>
                {expandedFAQ === index ? (
                  <ChevronDown className="w-5 h-5 text-gray-600 flex-shrink-0 ml-3" />
                ) : (
                  <ChevronRight className="w-5 h-5 text-gray-600 flex-shrink-0 ml-3" />
                )}
              </button>
              {expandedFAQ === index && (
                <div className="px-6 py-4 bg-blue-50 border-b border-gray-100">
                  <p className="text-gray-700 text-sm leading-relaxed">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Channels Section */}
        <div className="mt-8 px-6">
          <h2 className="text-lg font-bold text-gray-900 mb-4">canais de atendimento</h2>
        </div>

        <div className="bg-white mx-4 rounded-lg shadow-sm border border-gray-200">
          {channels.map((channel, index) => {
            const Icon = channel.icon;
            return (
              <div key={index}>
                <button
                  onClick={() => setExpandedChannel(expandedChannel === index ? null : index)}
                  className="w-full px-6 py-5 flex items-center justify-between hover:bg-blue-50 transition-all duration-200 border-b border-gray-100 last:border-b-0"
                >
                  <div className="flex items-center gap-4">
                    <Icon className="w-6 h-6 text-gray-700" />
                    <div className="text-left">
                      <div className="text-gray-900 font-normal">{channel.title}</div>
                    </div>
                  </div>
                  {expandedChannel === index ? (
                    <ChevronDown className="w-5 h-5 text-gray-600 flex-shrink-0" />
                  ) : (
                    <ChevronRight className="w-5 h-5 text-gray-600 flex-shrink-0" />
                  )}
                </button>
                {expandedChannel === index && (
                  <div className="px-6 py-4 bg-blue-50 border-b border-gray-100">
                    <p className="text-gray-700 text-sm leading-relaxed">{channel.details}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Start Chat Button */}
      <div className="p-6 bg-white border-t border-gray-200">
        <button
          onClick={() => setLocation("/chat")}
          className="w-full bg-[#FF6600] text-white py-4 rounded-lg font-semibold text-lg flex items-center justify-center gap-3 hover:bg-[#E55A00] transition-colors shadow-lg"
        >
          Iniciar chat
          <ChevronRight className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
}
