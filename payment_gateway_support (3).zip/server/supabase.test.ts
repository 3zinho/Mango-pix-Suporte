import { describe, it, expect } from 'vitest';
import { supabase } from './supabase';

describe('Supabase Connection', () => {
  it('should connect to Supabase successfully', async () => {
    // Testa conexão fazendo uma query simples
    const { data, error } = await supabase
      .from('_test_connection')
      .select('*')
      .limit(1);
    
    // Se a tabela não existir, o erro será "relation does not exist"
    // que é esperado. O importante é que a conexão funcionou.
    // Se as credenciais estiverem erradas, o erro será de autenticação.
    if (error) {
      // Verifica se o erro NÃO é de autenticação
      expect(error.message).not.toContain('Invalid API key');
      expect(error.message).not.toContain('JWT');
      expect(error.message).not.toContain('authentication');
    }
    
    // Se chegou aqui, a conexão está OK
    expect(supabase).toBeDefined();
  }, 10000); // 10s timeout para operações de rede
});
